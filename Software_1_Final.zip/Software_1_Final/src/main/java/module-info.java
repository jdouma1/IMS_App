module com.example.software_1_final {
    requires javafx.controls;
    requires javafx.fxml;
            
                            
    opens com.example.software_1_final to javafx.fxml;
    exports com.example.software_1_final;
}