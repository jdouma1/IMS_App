package com.example.software_1_final;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

/*
 * JavaDocs for project are generated for better view of functionality.
 * "Software_1_Final\Software_1_Final\src\main\resources\JavaDocs"
 * Located under Path from Content Root src/main/resources/JavaDocs
 */

/**
 * This class creates the Inventory Management System application and runs it.
 * <p>
 * FUTURE ENHANCEMENT: Functionality could be increased if users could create groups for parts and
 *                     products that are alike. They could narrow their search by finding and clicking
 *                     the group first, then searching from there.
 * @author Jacob Douma
 */
public class Main extends Application {
    /**
     * Creates and sets scene to stage.
     * @param stage to set different scenes on.
     * @throws IOException if unable to load Main Screen.
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("MainScreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Called when initially run to launch program.
     * @param args
     */
    public static void main(String[] args) {
        launch();
    }
}