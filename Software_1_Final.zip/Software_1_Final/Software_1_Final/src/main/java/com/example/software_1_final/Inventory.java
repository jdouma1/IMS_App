package com.example.software_1_final;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * This class is used to statically add and modify parts and products in inventory.
 * @author Jacob Douma
 */
public class Inventory {
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    private static int nextPartId = 0;
    private static int nextProductId = 0;

    /**
     * Gets the next added part's ID.
     * @return the next part ID when adding parts.
     */
    public static int getNextPartId() {
        nextPartId += 1;
        return nextPartId;
    }

    /**
     * Gets the next added product's ID.
     * @return the next product ID when adding products.
     */
    public static int getNextProductId() {
        nextProductId += 1;
        return nextProductId;
    }

    /**
     * Adds the new part to inventory.
     * Does not add the part if a part with the same name already exists.
     * @param newPart the new part to add to inventory.
     */
    public static boolean addPart(Part newPart) {
        String keyLowerCase = newPart.getName().toLowerCase();
        String partLowerCase;
        ObservableList<Part> allParts = getAllParts();

        for (Part part : allParts) {
            partLowerCase = part.getName().toLowerCase();
            if (keyLowerCase.equals(partLowerCase)) {
                return false;
            }
        }
        newPart.setId(getNextPartId());
        allParts.add(newPart);
        return true;
    }

    /**
     * Looks up part by ID.
     * @param partId the part ID to look up in inventory.
     * @return the part that was looked up.
     */
    public static Part lookupPart(int partId) {
        for (Part part : allParts) {
            if (part.getId() == partId) {
                return part;
            }
        }
        return null;
    }

    /**
     * Looks up the part by name (ignoring case).
     * @param partName the part to look up in inventory.
     * @return the list of parts with full or partial matching names (ignoring case).
     */
    public static ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> validParts = FXCollections.observableArrayList();
        for (Part part : allParts) {
            String keyLowerCase = partName.toLowerCase();
            String partLowerCase = part.getName().toLowerCase();
            if (partLowerCase.contains(keyLowerCase)) {
                validParts.add(part);
            }
        }
        return validParts;
    }

    /**
     * Updates the part with specified ID.
     * @param id the id that the part is identified with.
     * @param updatedPart the new part to update with.
     */
    public static void updatePart(int id, Part updatedPart) {
        for (int i = 0; i < allParts.size(); ++i) {
            if (allParts.get(i).getId() == id) {
                allParts.set(i, updatedPart);
                break;
            }
        }
    }

    /**
     * Deletes part from inventory.
     * @param selectedPart the part to be deleted from inventory.
     * @return boolean to determine whether part was deleted from inventory.
     */
    public static boolean deletePart(Part selectedPart) {
        return allParts.remove(selectedPart);
    }

    /**
     * Gets a list of all parts in inventory.
     * @return a list of all parts in inventory.
     */
    public static ObservableList<Part> getAllParts() { return allParts; }

    /**
     * Adds the new product to inventory.
     * Does not add the product if a part with the same name already exists.
     * @param newProduct the new product to add to inventory.
     */
    public static boolean addProduct(Product newProduct) {
        String keyLowerCase = newProduct.getName().toLowerCase();
        String productLowerCase;

        for (Product product : getAllProducts()) {
            productLowerCase = product.getName().toLowerCase();
            if (keyLowerCase.equals(productLowerCase)) {
                return false;
            }
        }
        newProduct.setId(Inventory.getNextProductId());
        allProducts.add(newProduct);
        return true;
    }

    /**
     * Looks up the product by ID.
     * @param productId the product id to look up in inventory.
     * @return the product that was looked up.
     */
    public static Product lookupProduct(int productId) {
        for (Product product : allProducts) {
            if (product.getId() == productId) {
                return product;
            }
        }
        return null;
    }

    /**
     * Looks up the product by name (ignoring case).
     * @param productName the product to look up in inventory.
     * @return the list of products with full or partial matching names (ignoring case).
     */
    public static ObservableList<Product> lookupProduct(String productName) {
        ObservableList<Product> validProducts = FXCollections.observableArrayList();
        for (Product product : allProducts) {
            String keyLowerCase = productName.toLowerCase();
            String productLowerCase = product.getName().toLowerCase();
            if (productLowerCase.contains(keyLowerCase)) {
                validProducts.add(product);
            }
        }
        return validProducts;
    }

    /**
     * Updates the product with specified ID.
     * @param id the index that the product is identified with.
     * @param updatedProduct the new product to update with.
     */
    public static void updateProduct(int id, Product updatedProduct) {
        for (int i = 0; i < allProducts.size(); ++i) {
            if (allProducts.get(i).getId() == id) {
                allProducts.set(i, updatedProduct);
                break;
            }
        }
    }

    /**
     * Deletes product from inventory.
     * @param selectedProduct the product to be deleted from inventory.
     * @return boolean to determine whether product was deleted from inventory.
     */
    public static boolean deleteProduct(Product selectedProduct) {
        selectedProduct.deleteAllAssociatedParts();
        return allProducts.remove(selectedProduct);
    }

    /**
     * Gets a list of all products in inventory.
     * @return a list of all products in inventory.
     */
    public static ObservableList<Product> getAllProducts() { return allProducts; }
}
