package com.example.software_1_final;

/**
 * This class extends the abstract Part class for InHouse parts.
 * @author Jacob Douma
 */
public class InHouse extends Part {
    private int machineId;

    /**
     * Creates InHouse part and initializes data.
     * @param id the InHouse part ID.
     * @param name the InHouse part name.
     * @param price the InHouse part price.
     * @param stock the InHouse part stock.
     * @param min the InHouse part min stock.
     * @param max the InHouse part max stock.
     * @param machineId the InHouse part company name.
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId) {
        super(id, name, price, stock, min, max);
        setMachineId(machineId);
    }

    /**
     * Sets the InHouse part's machine ID.
     * @param machineId the machine ID to set.
     */
    public void setMachineId(int machineId) { this.machineId = machineId; }

    /**
     * Gets the InHouse part's machine ID.
     * @return the machine ID.
     */
    public int getMachineId() { return machineId; }

    /**
     * Gets the type of part (InHouse).
     * <p>
     * RUNTIME ERROR: could not distinguish part type from ModifyPart, so method was added.
     * @return the type of Part (InHouse).
     */
    public String getPartType() { return "InHouse"; }
}
