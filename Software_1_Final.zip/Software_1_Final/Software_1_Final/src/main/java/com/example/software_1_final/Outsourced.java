package com.example.software_1_final;

/**
 * This class extends the abstract Part class for Outsourced parts.
 * @author Jacob Douma
 */
public class Outsourced extends Part {
    private String companyName;

    /**
     * Creates Outsourced part and initializes data.
     * @param name the Outsourced part name.
     * @param price the Outsourced part price.
     * @param stock the Outsourced part stock.
     * @param min the Outsourced part min stock.
     * @param max the Outsourced part max stock.
     * @param companyName the Outsourced part company name.
     */
    public Outsourced(String name, double price, int stock, int min, int max, String companyName) {
        super(name, price, stock, min, max);
        setCompanyName(companyName);
    }

    /**
     * Creates Outsourced part and initializes data.
     * @param id the Outsourced part id
     * @param name the Outsourced part name.
     * @param price the Outsourced part price.
     * @param stock the Outsourced part stock.
     * @param min the Outsourced part min stock.
     * @param max the Outsourced part max stock.
     * @param companyName the Outsourced part company name.
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        setCompanyName(companyName);
    }

    /**
     * Sets Outsourced part's company name.
     * @param companyName the company name to set.
     */
    public void setCompanyName(String companyName) { this.companyName = companyName; }

    /**
     * Gets Outsourced part's company name.
     * @return the company name.
     */
    public String getCompanyName() { return companyName; }
}
