package com.example.software_1_final;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

/**
 * This class is used to create products with associated parts to add to inventory.
 * @author Jacob Douma
 */
public class Product {
    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    /**
     * Creates product and initializes data.
     * @param id the product ID.
     * @param name the product name.
     * @param price the product price.
     * @param stock the product stock.
     * @param min the product min stock.
     * @param max the product max stock.
     */
    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }

    /**
     * Sets product ID.
     * @param id the product ID to set.
     */
    public void setId(int id) { this.id = id; }

    /**
     * Sets product name.
     * @param name the product name to set.
     */
    public void setName(String name) { this.name = name; }

    /**
     * Sets product price.
     * @param price the product price to set.
     */
    public void setPrice(double price) { this.price = price; }

    /**
     * Sets product stock.
     * @param stock the product stock to set.
     */
    public void setStock(int stock) { this.stock = stock; }

    /**
     * Sets product min stock.
     * @param min the min number of products to hold.
     */
    public void setMin(int min) { this.min = min; }

    /**
     * Sets product max stock.
     * @param max the max number of products to hold.
     */
    public void setMax(int max) { this.max = max; }

    /**
     * Gets the product ID.
     * @return the product id.
     */
    public int getId() { return id; }

    /**
     * Gets the product name.
     * @return the product name.
     */
    public String getName() {return name; }

    /**
     * Gets the product price.
     * @return the product price.
     */
    public double getPrice() { return price; }

    /**
     * Gets the product stock.
     * @return the product stock.
     */
    public int getStock() { return stock; }

    /**
     * Gets the product min stock.
     * @return the min number of product to hold.
     */
    public int getMin() { return min; }

    /**
     * Gets the product max stock.
     * @return the max number of product to hold.
     */
    public int getMax() { return max; }

    /**
     * Adds an associated part to the product and not duplicate a part that has already been added.
     * <p>
     * RUNTIME ERROR: associated parts were duplicated, so code was added below to check if part already exists.
     * @param newPart the associated part to add to product in order of ID number.
     */
    public void addAssociatedPart(Part newPart) {
        for (Part part : getAllAssociatedParts()) {
            if (newPart.getId() == part.getId()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Associated Parts");
                alert.setHeaderText("Add");
                alert.setContentText("This part has already been added");
                alert.show();
                return;
            }
        }

        associatedParts.add(newPart);
        for (int i = 0; i < associatedParts.size(); ++i) {
            if (newPart.getId() < associatedParts.get(i).getId()) {
                associatedParts.add(i, newPart);
                associatedParts.remove(i + 2);
                break;
            }
        }
    }

    /**
     * Deletes associated part from product.
     * @param selectedAssociatedPart the associated part to delete from product.
     * @return boolean to determine whether part was deleted from product.
     */
    public boolean deleteAssociatedPart(Part selectedAssociatedPart) { return associatedParts.remove(selectedAssociatedPart); }

    /**
     * Gets all associated parts.
     * @return list of all associated parts in product.
     */
    public ObservableList<Part> getAllAssociatedParts() { return associatedParts; }

    /**
     * Gets part specified by name.
     * <p>
     * RUNTIME ERROR: matching parts were not found, so added code to ignore case.
     * @param partName the part to look up in inventory.
     * @return the list of parts with full or partial matching names (ignoring case).
     */
    public ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> validParts = FXCollections.observableArrayList();
        for (Part part : associatedParts) {
            String keyLowerCase = partName.toLowerCase();
            String partLowerCase = part.getName().toLowerCase();
            if (partLowerCase.contains(keyLowerCase)) {
                validParts.add(part);
            }
        }
        return validParts;
    }
}
