package com.example.software_1_final;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * This class is used to control the Main Screen of IMS application.
 * @author Jacob Douma
 */
public class MainScreenController implements Initializable {
    //The parts Table
    public TableView partTable;
    public TableColumn partIdColumn;
    public TableColumn partNameColumn;
    public TableColumn partInventoryColumn;
    public TableColumn partPriceColumn;

    //The products table
    public TableView productTable;
    public TableColumn productIdColumn;
    public TableColumn productNameColumn;
    public TableColumn productInventoryColumn;
    public TableColumn productPriceColumn;
    public TextField partTableSearchBar;
    public TextField productTableSearchBar;

    //Used to initially populate with test data
    private static boolean populated = false;

    /**
     * Close program when clicked Exit button.
     * @param event the event item to collect user input.
     */
    public void onClickedExit(ActionEvent event) {
        Platform.exit();
    }

    /**
     * Opens AddPartScreen to fill out form and add part to inventory.
     * @param event the event item to collect user input.
     */
    public void onAddPart(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddPartScreen.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Opens ModifyPartScreen to fill out form and modify part information.
     * @param event the event item to collect user input.
     */
    public void onModifyPart(ActionEvent event) throws IOException {
        Part selectedPart = (Part) partTable.getSelectionModel().getSelectedItem();

        //Part not found
        if (selectedPart == null) {
            return;
        }
        //If part is of type InHouse
        else if (selectedPart instanceof InHouse) {
            InHouse part = (InHouse) selectedPart;
            ModifyPartScreenController.generatePart(part);
        }
        //If part is of type Outsourced
        else if (selectedPart instanceof Outsourced) {
            Outsourced part = (Outsourced) selectedPart;
            ModifyPartScreenController.generatePart(part);
        }

        Parent root = FXMLLoader.load(getClass().getResource("ModifyPartScreen.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Deletes selected part in table from inventory. Opens popup to affirm deletion.
     * @param event the event item to collect user input.
     */
    public void onDeletePart(ActionEvent event) {
        Part selectedPart = (Part) partTable.getSelectionModel().getSelectedItem();

        if (selectedPart != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Parts");
            alert.setHeaderText("Delete");
            alert.setContentText("Do you want to delete this part?");

            Optional<ButtonType> buttonResult = alert.showAndWait();

            if (buttonResult.isPresent() && buttonResult.get() == ButtonType.OK) {
                Inventory.deletePart(selectedPart);
            }
            partTable.setItems(Inventory.getAllParts());
        }
    }

    /**
     * Utilizes search bar to search by part ID and highlight or search by part name and show all full/partial matches.
     * @param event the event item to collect user input.
     */
    public void onSearchedPart(ActionEvent event) {
        //Reset table and selection for new search
        partTable.getSelectionModel().clearSelection();
        partTable.setItems(Inventory.getAllParts());

        String searchedPart = partTableSearchBar.getText();
        ObservableList<Part> relatedParts = Inventory.lookupPart(searchedPart);

        if (searchedPart.isEmpty()) {
            //Reset table to show all parts
            partTable.setItems(Inventory.getAllParts());
            return;
        }

        else if (relatedParts.size() == 0) {
            try {
                //Search by part ID
                int partId = Integer.parseInt(searchedPart);
                Part part = Inventory.lookupPart(partId);

                if (part != null) {
                    partTable.getSelectionModel().select(part);
                    return;
                }
            } catch (NumberFormatException e) {
                //Search not found
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Parts");
                alert.setHeaderText("Search");
                alert.setContentText("Part not found. Please refine search!");
                alert.show();
            }
        }

        partTable.setItems(relatedParts);
    }

    /**
     * Opens AddProductScreen to fill out form and add product to inventory.
     * @param event the event item to collect user input.
     */
    public void onAddProduct(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddProductScreen.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Opens ModifyProductScreen to fill out form and modify product information.
     * @param event the event item to collect user input.
     */
    public void onModifyProduct(ActionEvent event) throws IOException {
        Product selectedProduct = (Product) productTable.getSelectionModel().getSelectedItem();

        //Product not found
        if (selectedProduct == null) {
            return;
        }
        ModifyProductScreenController.generateProduct(selectedProduct);

        Parent root = FXMLLoader.load(getClass().getResource("ModifyProductScreen.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Deletes selected product in table from inventory. Opens popup to affirm deletion.
     * @param event the event item to collect user input.
     */
    public void onDeleteProduct(ActionEvent event) {
        Product selectedProduct = (Product) productTable.getSelectionModel().getSelectedItem();

        if (selectedProduct != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Products");
            alert.setHeaderText("Delete");
            alert.setContentText("Do you want to delete this product?");

            Optional<ButtonType> buttonResult = alert.showAndWait();

            if (buttonResult.isPresent() && buttonResult.get() == ButtonType.OK) {
                Inventory.deleteProduct(selectedProduct);
            }
            productTable.setItems(Inventory.getAllProducts());
        }
    }

    /**
     * Utilizes search bar to search by product ID and highlight or
     * search by product name and show all full/partial matches.
     * @param event the event item to collect user input.
     */
    public void onSearchedProduct(ActionEvent event) {
        //Reset table and selection for new search
        productTable.getSelectionModel().clearSelection();
        productTable.setItems(Inventory.getAllProducts());

        String searchedProduct = productTableSearchBar.getText();
        ObservableList<Product> relatedProducts = Inventory.lookupProduct(searchedProduct);

        if (searchedProduct.isEmpty()) {
            //Reset table to show all product
            productTable.setItems(Inventory.getAllProducts());
            return;
        }

        if (relatedProducts.size() == 0) {
            try {
                //Search by product ID
                int productId = Integer.parseInt(searchedProduct);
                Product product = Inventory.lookupProduct(productId);

                if (product != null) {
                    productTable.getSelectionModel().select(product);
                    return;
                }
            } catch (NumberFormatException e) {
                //Search not found
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Products");
                alert.setHeaderText("Search");
                alert.setContentText("Product not found. Please refine search!");
                alert.show();
            }
        }
        productTable.setItems(relatedProducts);
    }

    /** This method is invoked upon initialization of the Main Screen.
     * It is invoked only the first time to create sample data.
     */
    public void populate() {
        if (populated) {
            return;
        }
        populated = true;

        InHouse part1 = new InHouse("Brakes", 12.99, 15, 1, 30, 111);
        Inventory.addPart(part1);
        InHouse part2 = new InHouse("Tire", 14.99, 15, 2, 60, 130);
        Inventory.addPart(part2);
        Outsourced part3 = new Outsourced("Rim", 56.99, 15, 2, 60, "Super Bikes");
        Inventory.addPart(part3);

        Product product1 = new Product("Giant Bicycle", 299.99, 10, 1, 20);
        product1.addAssociatedPart(Inventory.getAllParts().get(0));
        product1.addAssociatedPart(Inventory.getAllParts().get(1));
        product1.addAssociatedPart(Inventory.getAllParts().get(2));
        Inventory.addProduct(product1);

        Product product2 = new Product("Scott Bicycle", 199.99, 13, 1, 20);
        product2.addAssociatedPart(Inventory.getAllParts().get(0));
        product2.addAssociatedPart(Inventory.getAllParts().get(1));
        product2.addAssociatedPart(Inventory.getAllParts().get(2));
        Inventory.addProduct(product2);

        Product product3 = new Product("GT Bike", 99.99, 11, 1, 20);
        product3.addAssociatedPart(Inventory.getAllParts().get(0));
        product3.addAssociatedPart(Inventory.getAllParts().get(1));
        product3.addAssociatedPart(Inventory.getAllParts().get(2));
        Inventory.addProduct(product3);
    }

    /**
     * This method is invoked every time upon return to the Main Screen.
     * It will populate with test data only on the first time.
     * It will set the tables and columns values.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        populate();

        partIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        productIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        partTable.setItems(Inventory.getAllParts());
        productTable.setItems(Inventory.getAllProducts());
    }
}
