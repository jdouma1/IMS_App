package com.example.software_1_final;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is used to control the Add Product Screen of IMS application.
 * @author Jacob Douma
 */
public class AddProductScreenController implements Initializable {
    //Label used to display error messages for input validation
    public Label enterInfoLabel;

    //Product data text fields and search bar
    public TextField partTableSearchBar;
    public TextField idTextField;
    public TextField nameTextField;
    public TextField invTextField;
    public TextField priceTextField;
    public TextField maxTextField;
    public TextField minTextField;

    //Table of available parts to associate with product
    public TableView addPartTable;
    public TableColumn addPartIdColumn;
    public TableColumn addPartNameColumn;
    public TableColumn addPartInventoryColumn;
    public TableColumn addPartPriceColumn;

    //Table of parts associated with product
    public TableView removePartTable;
    public TableColumn removePartIdColumn;
    public TableColumn removePartNameColumn;
    public TableColumn removePartInventoryColumn;
    public TableColumn removePartPriceColumn;

    //Buttons to add, remove, save, cancel
    public Button addPartButton;
    public Button removePartButton;
    public Button saveProductButton;
    public Button cancelProductButton;

    //Variables used to ensure data input validation
    private boolean validName = false;
    private boolean validPrice = false;
    private boolean validStock = false;
    private boolean validMin = false;
    private boolean validMax = false;

    //Product data
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    //Related parts to associate with product before adding to inventory
    private ObservableList<Part> relatedParts = FXCollections.observableArrayList();

    /**
     * This method is invoked every time upon call to modify part to initialize addPartTable with parts from inventory.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        addPartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        addPartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        addPartInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        addPartPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        removePartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        removePartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        removePartInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        removePartPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        addPartTable.setItems(Inventory.getAllParts());
    }

    /**
     * Checks input text fields to validate then creates product and adds it to inventory.
     * <p>
     * RUNTIME ERROR: could not save product, needed to check "button".isSelected() instead of "button".isPressed().
     * <p>
     * RUNTIME ERROR: needed to create separate list for associatedParts then add individually before pushing product to inventory,
     *                since product fields needed to be validated first.
     * @param event used to collect user input.
     * @throws IOException if MainScreen cannot be opened.
     */
    public void onSaveProduct(ActionEvent event) throws IOException {
        //Input validation
        checkName();
        checkPrice();
        checkInv();
        checkMin();
        checkMax();

        //Input not valid
        if (!(validName && validPrice && validStock && validMin && validMax)) {
            return;
        }

        //Ensure inventory min < stock < max
        if (!(min < stock && stock < max)) {
            validMin = false;
            validStock = false;
            validMax = false;
            enterInfoLabel.setText("Please ensure min < inv < max");
            return;
        }
        id = Inventory.getNextProductId();
        Product product = new Product(id, name, price, stock, min, max);

        //Add associated parts to product before pushing to inventory
        for (Part relatedPart : relatedParts) {
            product.addAssociatedPart(relatedPart);
        }
        Inventory.addProduct(product);

        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Cancels product from being created.
     * @param event used to collect user input.
     * @throws IOException if MainScreen cannot be opened.
     */
    public void onCancelProduct(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Utilizes search bar to search by part ID and highlight or search by part name and show all full/partial matches.
     * <p>
     * RUNTIME ERROR: if search not found, I needed to clear search bar and search empty to restore table;
     *                Selection would not go away;
     *                I solved this by adding "".clearSelection() at top and reset items in table to restore
     *                before searching again.
     * @param actionEvent the event item to collect user input.
     */
    public void onSearchedPart(ActionEvent actionEvent) {
        //Reset table and selection for new search
        addPartTable.getSelectionModel().clearSelection();
        addPartTable.setItems(Inventory.getAllParts());

        String searchKey = partTableSearchBar.getText();
        ObservableList<Part> searchedParts = Inventory.lookupPart(searchKey);

        //Empty search bar
        if (searchKey.isEmpty()) {
            //Display all parts from inventory
            addPartTable.setItems(Inventory.getAllParts());
            return;
        }

        if (searchedParts.size() == 0) {
            try {
                //Search by part ID
                int partId = Integer.parseInt(searchKey);
                Part part = Inventory.lookupPart(partId);

                if (part != null) {
                    addPartTable.getSelectionModel().select(part);
                    return;
                }
            } catch (NumberFormatException e) {
                //Search not found
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Parts");
                alert.setHeaderText("Search");
                alert.setContentText("Part not found. Please refine search!");
                alert.show();
            }
        }

        addPartTable.setItems(searchedParts);
    }

    /**
     * Adds part from inventory to list of associated parts.
     * <p>
     * RUNTIME ERROR: needed to check if list of related parts was empty before
     *                checking if part was already present in list.
     * @param actionEvent used to collect user input.
     */
    public void onAddPart(ActionEvent actionEvent) {
        Part selectedPart = (Part) addPartTable.getSelectionModel().getSelectedItem();

        //Edge case to add initial part to list
        if (relatedParts.size() == 0) {
            relatedParts.add(selectedPart);
            removePartTable.setItems(relatedParts);
            return;
        }
        //Check if part already exists in list (no duplicates)
        else if (relatedParts.contains(selectedPart)) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Associated Parts");
            alert.setHeaderText("Add");
            alert.setContentText("This part has already been added");
            alert.show();
            return;
        }

        //Set list of assoicated parts in order by ID
        for (int i = 0; i < relatedParts.size(); ++i) {
            if (selectedPart.getId() < relatedParts.get(i).getId()) {
                relatedParts.add(i, selectedPart);
                removePartTable.setItems(relatedParts);
                return;
            }
        }
    }

    /**
     * Popup window to confirm removing associated part then removing that part from the table.
     * @param actionEvent used to collect user input.
     */
    public void onRemovePart(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Associated Parts");
        alert.setHeaderText("Delete");
        alert.setContentText("Are you sure you want to remove this associated part?");

        Optional<ButtonType> buttonResult = alert.showAndWait();

        if (buttonResult.isPresent() && buttonResult.get() == ButtonType.OK) {
            Part selectedPart = (Part) removePartTable.getSelectionModel().getSelectedItem();
            relatedParts.remove(selectedPart);
            removePartTable.setItems(relatedParts);
        }
    }

    /**
     * Uses Regular Expressions to validate part name is any sequence of alphabetic letters and spaces.
     * <p>
     * RUNTIME ERROR: name did not allow spaces, needed to apply regex found below instead of "[a-zA-Z]+".
     */
    public void checkName() {
        if (!nameTextField.getText().isBlank()) {
            Pattern p = Pattern.compile("[a-zA-Z]+[ a-zA-Z]*");
            Matcher m = p.matcher(nameTextField.getText());
            if (m.matches()) {
                name = nameTextField.getText();
                validName = true;
                return;
            }
        }
        enterInfoLabel.setText("Please enter a valid name");
        validName = false;
    }

    /** Checks to ensure price is valid Double. */
    public void checkPrice() {
        if (!priceTextField.getText().isBlank()) {
            String priceString = priceTextField.getText();

            try {
                price = Double.parseDouble(priceString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid price");
                validPrice = false;
                return;
            }
            validPrice = true;
            return;
        }
        enterInfoLabel.setText("Please enter a valid price");
        validPrice = false;
    }

    /** Checks to ensure inventory(stock) is valid integer. */
    public void checkInv() {
        if (!invTextField.getText().isBlank()) {
            String invString = invTextField.getText();

            try {
                stock = Integer.parseInt(invString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid inventory level");
                validStock = false;
                return;
            }
            validStock = true;
            return;
        }
        enterInfoLabel.setText("Please enter a valid inventory level");
        validStock = false;
    }

    /** Checks to ensure inventory max is valid integer. */
    public void checkMax() {
        if (!maxTextField.getText().isBlank()) {
            String maxString = maxTextField.getText();

            try {
                max = Integer.parseInt(maxString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid inventory max");
                validMax = false;
                return;
            }
            validMax = true;
            return;
        }
        enterInfoLabel.setText("Please enter a valid inventory max");
        validMax = false;
    }

    /** Checks to ensure inventory min is valid integer. */
    public void checkMin() {
        if (!minTextField.getText().isBlank()) {
            String minString = minTextField.getText();

            try {
                min = Integer.parseInt(minString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid inventory min");
                validMin = false;
                return;
            }
            validMin = true;
            return;
        }
        enterInfoLabel.setText("Please enter a valid inventory min");
        validMin = false;
    }
}
