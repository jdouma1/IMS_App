package com.example.software_1_final;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is used to control the Modify Product Screen of IMS application.
 * @author Jacob Douma
 */
public class ModifyProductScreenController implements Initializable {
    //Label used to display error messages for input validation
    public Label enterInfoLabel;

    //Product data text fields and search bar
    public TextField partTableSearchBar;
    public TextField idTextField;
    public TextField nameTextField;
    public TextField invTextField;
    public TextField priceTextField;
    public TextField maxTextField;
    public TextField minTextField;

    //Table of available parts to associate with product
    public TableView addPartTable;
    public TableColumn addPartIdColumn;
    public TableColumn addPartNameColumn;
    public TableColumn addPartInventoryColumn;
    public TableColumn addPartPriceColumn;

    //Table of parts associated with product
    public TableView removePartTable;
    public TableColumn removePartIdColumn;
    public TableColumn removePartNameColumn;
    public TableColumn removePartInventoryColumn;
    public TableColumn removePartPriceColumn;

    //Buttons to add, remove, save, cancel
    public Button addPartButton;
    public Button removePartButton;
    public Button saveProductButton;
    public Button cancelProductButton;

    //Product data
    private Product modifiedProduct = new Product();
    private static int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    //Selected product passed from MainScreen to be modified
    private static Product product;

    /**
     * This method is invoked every time upon call to modifyProduct to initialize addPartTable
     *      with parts from inventory, removePartTable with all
     *      associated parts, and text fields with product data.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idTextField.setText(String.valueOf(product.getId()));
        nameTextField.setText(String.valueOf(product.getName()));
        invTextField.setText(String.valueOf(product.getStock()));
        priceTextField.setText(String.valueOf(product.getPrice()));
        maxTextField.setText(String.valueOf(product.getMax()));
        minTextField.setText(String.valueOf(product.getMin()));

        addPartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        addPartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        addPartInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        addPartPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        removePartIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        removePartNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        removePartInventoryColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        removePartPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        addPartTable.setItems(Inventory.getAllParts());
        removePartTable.setItems(product.getAllAssociatedParts());

        copyProduct();
    }

    /** Sets static elements for product to initialize when window is opened.
     * This ensures we know the product ID and have a copy of the product to update its details.
     */
    public static void generateProduct(Product p) {
        product = p;
        id = product.getId();
    }

    /**
     * Sets the attributes to the temporary product before updating the current product details in inventory.
     */
    public void setAttributes() {
        modifiedProduct.setName(name);
        modifiedProduct.setPrice(price);
        modifiedProduct.setStock(stock);
        modifiedProduct.setMin(min);
        modifiedProduct.setMax(max);
    }

    /**
     * Copies the product attributes to the placeholder product to modify.
     */
    public void copyProduct() {
        modifiedProduct.setId(product.getId());
        modifiedProduct.setName(product.getName());
        modifiedProduct.setPrice(product.getPrice());
        modifiedProduct.setStock(product.getStock());
        modifiedProduct.setMin(product.getMin());
        modifiedProduct.setMax(product.getMax());

        ObservableList<Part> allParts = product.getAllAssociatedParts();
        for (Part part : allParts) {
            modifiedProduct.addAssociatedPart(part);
        }
    }
    /**
     * Checks input text fields to validate then creates product and adds it to inventory.
     * @param event used to collect user input.
     * @param event used to collect user input.
     * @throws IOException if MainScreen cannot be opened.
     */
    public void onSaveProduct(ActionEvent event) throws IOException {
        //Input not valid
        if (!(checkName() && checkPrice() && checkInv() && checkMin() && checkMax())) {
            return;
        }

        //Ensure inventory min <= stock <= max
        if (!(min <= stock && stock <= max)) {
            enterInfoLabel.setText("Please ensure min <= inv <= max");
            return;
        }
        setAttributes();
        Inventory.updateProduct(id, modifiedProduct);

        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Cancels product from being modified.
     * @param event used to collect user input.
     * @throws IOException if MainScreen cannot be opened.
     */
    public void onCancelProduct(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Utilizes search bar to search by part ID and highlight or search by part name and show all full/partial matches.
     * @param actionEvent the event item to collect user input.
     */
    public void onSearchedPart(ActionEvent actionEvent) {
        //Reset table and selection for new search
        addPartTable.getSelectionModel().clearSelection();
        addPartTable.setItems(Inventory.getAllParts());

        String searchKey = partTableSearchBar.getText();
        ObservableList<Part> searchedParts = Inventory.lookupPart(searchKey);

        //Empty search bar
        if (searchKey.isEmpty()) {
            //Display all parts from inventory
            addPartTable.setItems(Inventory.getAllParts());
            return;
        }

        if (searchedParts.isEmpty()) {
            try {
                //Search by part ID
                int partId = Integer.parseInt(searchKey);
                Part part = Inventory.lookupPart(partId);

                if (part != null) {
                    addPartTable.getSelectionModel().select(part);
                    return;
                }
            } catch (NumberFormatException e) {
                //Search not found
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Parts");
                alert.setHeaderText("Search");
                alert.setContentText("Part not found. Please refine search!");
                alert.show();
            }
        }
        addPartTable.setItems(searchedParts);
    }

    /**
     * Adds part from inventory to list of associated parts.
     * @param actionEvent used to collect user input.
     */
    public void onAddPart(ActionEvent actionEvent) {
        Part selectedPart = (Part) addPartTable.getSelectionModel().getSelectedItem();
        modifiedProduct.addAssociatedPart(selectedPart);
        removePartTable.setItems(modifiedProduct.getAllAssociatedParts());
    }

    /**
     * Popup window to confirm removing associated part then removing that part from the table.
     * @param actionEvent used to collect user input.
     */
    public void onRemovePart(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Associated Parts");
        alert.setHeaderText("Delete");
        alert.setContentText("Are you sure you want to remove this associated part?");

        Optional<ButtonType> buttonResult = alert.showAndWait();

        if (buttonResult.isPresent() && buttonResult.get() == ButtonType.OK) {
            Part selectedPart = (Part) removePartTable.getSelectionModel().getSelectedItem();
            modifiedProduct.deleteAssociatedPart(selectedPart);
            removePartTable.setItems(modifiedProduct.getAllAssociatedParts());
        }
    }

    /**
     * Uses Regular Expressions to validate part name is any sequence of alphabetic letters and spaces.
     */
    public boolean checkName() {
        if (!nameTextField.getText().isBlank()) {
            Pattern p = Pattern.compile("[a-zA-Z]+[ a-zA-Z]*");
            Matcher m = p.matcher(nameTextField.getText());
            if (m.matches()) {
                name = nameTextField.getText();
                return true;
            }
        }
        enterInfoLabel.setText("Please enter a valid name (alphabetical)");
        return false;
    }

    /** Checks to ensure price is valid Double. */
    public boolean checkPrice() {
        if (!priceTextField.getText().isBlank()) {
            String priceString = priceTextField.getText();

            try {
                price = Double.parseDouble(priceString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid price");
                return false;
            }
            return true;
        }
        enterInfoLabel.setText("Please enter a valid price");
        return false;
    }

    /** Checks to ensure inventory(stock) is valid integer. */
    public boolean checkInv() {
        if (!invTextField.getText().isBlank()) {
            String invString = invTextField.getText();

            try {
                stock = Integer.parseInt(invString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid inventory level");
                return false;
            }
            return true;
        }
        enterInfoLabel.setText("Please enter a valid inventory level");
        return false;
    }

    /** Checks to ensure inventory max is valid integer. */
    public boolean checkMax() {
        if (!maxTextField.getText().isBlank()) {
            String maxString = maxTextField.getText();

            try {
                max = Integer.parseInt(maxString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid inventory max");
                return false;
            }
            return true;
        }
        enterInfoLabel.setText("Please enter a valid inventory max");
        return false;
    }

    /** Checks to ensure inventory min is valid integer. */
    public boolean checkMin() {
        if (!minTextField.getText().isBlank()) {
            String minString = minTextField.getText();

            try {
                min = Integer.parseInt(minString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid inventory min");
                return false;
            }
            return true;
        }
        enterInfoLabel.setText("Please enter a valid inventory min");
        return false;
    }
}
