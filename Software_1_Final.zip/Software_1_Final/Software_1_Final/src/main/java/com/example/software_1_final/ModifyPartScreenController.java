package com.example.software_1_final;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is used to control the Modify Part Screen of IMS application.
 * @author Jacob Douma
 */
public class ModifyPartScreenController implements Initializable {
    //Switch label depending on part type (InHouse or Outsourced)
    public Label idNameLabel;
    //Label used to display error messages for input validation
    public Label enterInfoLabel;

    //Part data text fields
    public TextField idTextField;
    public TextField nameTextField;
    public TextField invTextField;
    public TextField priceTextField;
    public TextField maxTextField;
    public TextField minTextField;
    public TextField idNameTextField;

    //Buttons used to switch part type to InHouse or Outsourced
    public RadioButton inHouseButton;
    public RadioButton outsourcedButton;

    //Static parts to initialize depending on which part type it is
    private static InHouse inHousePart;
    private static Outsourced outsourcedPart;

    //Static string passed to differentiate which type of part it is
    private static String partType;

    //Part data
    private static int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;
    private int machineId;
    private String companyName;

    /**
     * This method is invoked every time upon call to modify part to initialize data from selected part.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if (partType.equals("InHouse")) {
            inHouseButton.setSelected(true);
            idNameLabel.setText("Machine ID");

            idTextField.setText(String.valueOf(inHousePart.getId()));
            nameTextField.setText(String.valueOf(inHousePart.getName()));
            invTextField.setText(String.valueOf(inHousePart.getStock()));
            priceTextField.setText(String.valueOf(inHousePart.getPrice()));
            maxTextField.setText(String.valueOf(inHousePart.getMax()));
            minTextField.setText(String.valueOf(inHousePart.getMin()));
            idNameTextField.setText(String.valueOf(inHousePart.getMachineId()));
        }
        else {
            outsourcedButton.setSelected(true);
            idNameLabel.setText("Company Name");

            idTextField.setText(String.valueOf(outsourcedPart.getId()));
            nameTextField.setText(String.valueOf(outsourcedPart.getName()));
            invTextField.setText(String.valueOf(outsourcedPart.getStock()));
            priceTextField.setText(String.valueOf(outsourcedPart.getPrice()));
            maxTextField.setText(String.valueOf(outsourcedPart.getMax()));
            minTextField.setText(String.valueOf(outsourcedPart.getMin()));
            idNameTextField.setText(String.valueOf(outsourcedPart.getCompanyName()));
        }
    }

    /** Sets static elements for InHouse part to initialize when window is opened.
     * This ensures we know the part ID and part type.
     */
    public static void generatePart(InHouse part) {
        inHousePart = part;
        partType = "InHouse";
        id = inHousePart.getId();
    }

    /** Sets static elements for Outsourced part to initialize when window is opened.
     * This ensures we know the part ID and part type.
     */
    public static void generatePart(Outsourced part) {
        outsourcedPart = part;
        partType = "Outsourced";
        id = outsourcedPart.getId();
    }

    /**
     * Checks input text fields to validate then modifies part and replaces it in inventory.
     * @param event used to collect user input.
     * @throws IOException if MainScreen cannot be opened.
     */
    public void onSavePart(ActionEvent event) throws IOException {
        //Remove error message label
        enterInfoLabel.setText("");

        //Input not valid
        if (!(checkName() && checkPrice() && checkInv() && checkMin() && checkMax() && checkIdName())) {
            return;
        }

        //Ensure inventory min <= stock <= max
        if (!(min <= stock && stock <= max)) {
            enterInfoLabel.setText("Please ensure min <= inv <= max");
            return;
        }

        if (inHouseButton.isSelected()) {
            partType = "InHouse";
            inHousePart = new InHouse(id, name, price, stock, min, max, machineId);
            Inventory.updatePart(id, inHousePart);
        }
        else {
            partType = "Outsourced";
            outsourcedPart = new Outsourced(id, name, price, stock, min, max, companyName);
            Inventory.updatePart(id, outsourcedPart);
        }
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Cancels part from being modified.
     * @param event used to collect user input.
     * @throws IOException if MainScreen cannot be opened.
     */
    public void onCancelPart(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * If InHouse button selected, set Label to "Machine ID".
     * @param actionEvent used to collect user input.
     */
    public void onSelectedInHouse(ActionEvent actionEvent){ idNameLabel.setText("Machine ID");}

    /**
     * If Outsourced button selected, set Label to "Company Name".
     * @param actionEvent used to collect user input.
     */
    public void onSelectedOutsourced(ActionEvent actionEvent){
        idNameLabel.setText("Company Name");
    }

    /**
     * Uses Regular Expressions to validate part name is any sequence of alphabetic letters and spaces.
     */
    public boolean checkName() {
        if (!nameTextField.getText().isBlank()) {
            Pattern p = Pattern.compile("[a-zA-Z]+[ a-zA-Z]*");
            Matcher m = p.matcher(nameTextField.getText());
            if (m.matches()) {
                name = nameTextField.getText();
                return true;
            }
        }
        enterInfoLabel.setText("Please enter a valid name (alphabetical)");
        return false;
    }

    /** Checks to ensure price is valid Double. */
    public boolean checkPrice() {
        if (!priceTextField.getText().isBlank()) {
            String priceString = priceTextField.getText();

            try {
                price = Double.parseDouble(priceString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid price");
                return false;
            }
            return true;
        }
        enterInfoLabel.setText("Please enter a valid price");
        return false;
    }

    /** Checks to ensure inventory(stock) is valid integer. */
    public boolean checkInv() {
        if (!invTextField.getText().isBlank()) {
            String invString = invTextField.getText();

            try {
                stock = Integer.parseInt(invString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid inventory level");
                return false;
            }
            return true;
        }
        enterInfoLabel.setText("Please enter a valid inventory level");
        return false;
    }

    /** Checks to ensure inventory max is valid integer. */
    public boolean checkMax() {
        if (!maxTextField.getText().isBlank()) {
            String maxString = maxTextField.getText();

            try {
                max = Integer.parseInt(maxString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid inventory max");
                return false;
            }
            return true;
        }
        enterInfoLabel.setText("Please enter a valid inventory max");
        return false;
    }

    /** Checks to ensure inventory min is valid integer. */
    public boolean checkMin() {
        if (!minTextField.getText().isBlank()) {
            String minString = minTextField.getText();

            try {
                min = Integer.parseInt(minString);
            }
            catch(NumberFormatException e) {
                enterInfoLabel.setText("Please enter a valid inventory min");
                return false;
            }
            return true;
        }
        enterInfoLabel.setText("Please enter a valid inventory min");
        return false;
    }

    /**
     * If InHouse button selected, ensures valid integer machine ID. If Outsourced button selected, ensures valid string
     *            company name of alphabetic letters and spaces.
     */
    public boolean checkIdName() {
        if (inHouseButton.isSelected()) {
            if (!idNameTextField.getText().isBlank()) {
                try {
                    machineId = Integer.parseInt(idNameTextField.getText());
                }
                catch(NumberFormatException e) {
                    enterInfoLabel.setText("Please enter a valid machine ID (numerical)");
                    return false;
                }
                return true;
            }
            enterInfoLabel.setText("Please enter a valid machine ID (numerical)");
        }
        else if (outsourcedButton.isSelected()) {
            if (!idNameTextField.getText().isBlank()) {
                Pattern p = Pattern.compile("[a-zA-Z]+[ a-zA-Z]*");
                Matcher m = p.matcher(idNameTextField.getText());
                if (m.matches()) {
                    companyName = idNameTextField.getText();
                    return true;
                }
            }
            enterInfoLabel.setText("Please enter a valid company name (alphabetical)");
        }
        return false;
    }
}
